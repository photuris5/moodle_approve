<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Library functions for local_approve_accounts.
 *
 * @package    local_approve_accounts
 * @copyright  2025 Your Organisation
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Extend the main navigation with a "Pending Approvals" link for approvers.
 *
 * @param global_navigation $navigation
 */
function local_approve_accounts_extend_navigation(global_navigation $navigation) {
    global $USER, $DB;

    if (!isloggedin() || isguestuser()) {
        return;
    }

    $context = context_system::instance();
    if (!has_capability('local/approve_accounts:approve', $context)) {
        return;
    }

    // Only show if the user is a designated approver.
    if (!$DB->record_exists('local_approve_accounts_approvers', ['userid' => $USER->id])) {
        return;
    }

    // Count pending approvals for the badge.
    $pendingcount = $DB->count_records('local_approve_accounts_pending', [
        'status' => \local_approve_accounts\manager::STATUS_PENDING,
    ]);

    $label = get_string('navpending', 'local_approve_accounts');
    if ($pendingcount > 0) {
        $label .= ' (' . $pendingcount . ')';
    }

    $url = new moodle_url('/local/approve_accounts/pending.php');
    $navigation->add(
        $label,
        $url,
        navigation_node::TYPE_CUSTOM,
        null,
        'local_approve_accounts_pending',
        new pix_icon('i/checkpermissions', '')
    );
}
