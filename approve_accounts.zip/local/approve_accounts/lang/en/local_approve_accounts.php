<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings for local_approve_accounts.
 *
 * @package    local_approve_accounts
 * @copyright  2025 Your Organisation
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// General.
$string['pluginname'] = 'Account Approval';
$string['plugindesc'] = 'Requires designated approvers to approve new self-registered accounts before users can log in.';

// Capabilities.
$string['approve_accounts:approve'] = 'Approve or deny pending accounts';
$string['approve_accounts:manageapprovers'] = 'Manage designated approvers';

// Settings.
$string['enabled'] = 'Enable account approval';
$string['enabled_desc'] = 'When enabled, new email self-registrations will be suspended pending approval. When disabled, the plugin takes no action.';
$string['defaultrole'] = 'Role to assign on approval';
$string['defaultrole_desc'] = 'Select the role that will be assigned at system level when an account is approved.';
$string['authmethod'] = 'Authentication methods to intercept';
$string['authmethod_desc'] = 'Only users registering via these authentication methods will require approval. Typically only "Email-based self-registration".';
$string['notifysubject'] = 'Approver notification subject';
$string['notifysubject_desc'] = 'Email subject sent to approvers. Use {$a->fullname} and {$a->email} as placeholders.';
$string['notifysubject_default'] = 'New signup waiting for your review: {$a->fullname}';
$string['approvedsubject'] = 'Approval email subject';
$string['approvedsubject_desc'] = 'Email subject sent to users when approved. Use {$a->sitename} as placeholder.';
$string['approvedsubject_default'] = 'You are all set! Your {$a->sitename} account is approved';
$string['deniedsubject'] = 'Denial email subject';
$string['deniedsubject_desc'] = 'Email subject sent to users when denied. Use {$a->sitename} as placeholder.';
$string['deniedsubject_default'] = 'Update on your {$a->sitename} registration';
$string['manageapproverslink'] = 'Manage designated approvers';

// Pending page.
$string['pendingapprovals'] = 'Pending Approvals';
$string['nopending'] = 'No pending registrations.';
$string['fullname'] = 'Full name';
$string['email'] = 'Email';
$string['username'] = 'Username';
$string['dateregistered'] = 'Date registered';
$string['status'] = 'Status';
$string['actions'] = 'Actions';
$string['statuspending'] = 'Pending';
$string['statusapproved'] = 'Approved';
$string['statusdenied'] = 'Denied';
$string['approve'] = 'Approve';
$string['deny'] = 'Deny';
$string['filter_all'] = 'All';
$string['filter_pending'] = 'Pending';
$string['filter_approved'] = 'Approved';
$string['filter_denied'] = 'Denied';
$string['approvedby'] = 'Processed by';
$string['timeprocessed'] = 'Date processed';

// Approve/deny actions.
$string['confirmpapprove'] = 'Are you sure you want to approve this account?';
$string['userapprovesuccess'] = 'Account for {$a} has been approved.';
$string['userdenysuccess'] = 'Account for {$a} has been denied.';
$string['alreadyprocessed'] = 'This registration has already been processed.';
$string['invalidpending'] = 'Invalid pending record.';
$string['denyreason'] = 'Reason for denial';
$string['denyreason_help'] = 'Optionally provide a reason. This will be included in the email to the user.';
$string['confirmdenial'] = 'Deny account registration';

// Manage approvers page.
$string['manageapprovers'] = 'Manage Approvers';
$string['currentapprovers'] = 'Current approvers';
$string['noapprovers'] = 'No approvers have been designated yet.';
$string['addapprover'] = 'Add approver';
$string['removeapprover'] = 'Remove';
$string['confirmremoveapprover'] = 'Are you sure you want to remove {$a} as an approver?';
$string['approveradded'] = '{$a} has been added as an approver.';
$string['approverremoved'] = '{$a} has been removed as an approver.';
$string['approveralreadyexists'] = '{$a} is already a designated approver.';
$string['selectuser'] = 'Search for a user...';
$string['dateadded'] = 'Date added';

// Email content.
$string['email_approver_body'] = 'Hi there,

A new user has just signed up and is waiting for your review.

Name: {$a->fullname}
Email: {$a->email}
Username: {$a->username}
Registered: {$a->date}

You can review this request and any other pending registrations here:
{$a->pendingurl}

Thanks for helping keep things running smoothly!';

$string['email_approved_body'] = 'Hi {$a->fullname},

Great news! Your account at {$a->sitename} has been approved and is ready to go.

You can log in anytime at:
{$a->loginurl}

We are glad to have you on board. If you have any questions or need help getting started, feel free to reach out to us at {$a->supportemail}.

Welcome aboard!';

$string['email_denied_body'] = 'Hi {$a->fullname},

Thank you for your interest in {$a->sitename}. Unfortunately, we were unable to approve your registration at this time.

{$a->reason}

If you think this was a mistake or you would like more information, please do not hesitate to contact us at {$a->supportemail}. We are happy to help.

All the best.';

$string['email_denied_reason'] = 'Reason: {$a}';

// Message providers.
$string['messageprovider:newregistration'] = 'New account pending approval';
$string['messageprovider:accountapproved'] = 'Account approved notification';
$string['messageprovider:accountdenied'] = 'Account denied notification';

// Navigation.
$string['navpending'] = 'Pending Approvals';

// Privacy.
$string['privacy:metadata:local_approve_accounts_pending'] = 'Stores account approval status for self-registered users.';
$string['privacy:metadata:local_approve_accounts_pending:userid'] = 'The ID of the user whose registration is pending.';
$string['privacy:metadata:local_approve_accounts_pending:status'] = 'The approval status (pending, approved, denied).';
$string['privacy:metadata:local_approve_accounts_pending:denyreason'] = 'The reason given if the registration was denied.';
$string['privacy:metadata:local_approve_accounts_approvers'] = 'Stores which users are designated as account approvers.';
$string['privacy:metadata:local_approve_accounts_approvers:userid'] = 'The ID of the designated approver user.';
