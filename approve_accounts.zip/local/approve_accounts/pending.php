<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Pending approvals list.
 *
 * @package    local_approve_accounts
 * @copyright  2025 Your Organisation
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

use local_approve_accounts\manager;

require_login();
$context = context_system::instance();
require_capability('local/approve_accounts:approve', $context);

$filter = optional_param('filter', 'pending', PARAM_ALPHA);

$PAGE->set_url(new moodle_url('/local/approve_accounts/pending.php', ['filter' => $filter]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('pendingapprovals', 'local_approve_accounts'));
$PAGE->set_heading(get_string('pendingapprovals', 'local_approve_accounts'));
$PAGE->set_pagelayout('admin');

echo $OUTPUT->header();

// Filter tabs.
$filtermap = [
    'pending' => manager::STATUS_PENDING,
    'approved' => manager::STATUS_APPROVED,
    'denied' => manager::STATUS_DENIED,
    'all' => null,
];

$tabs = [];
foreach (['pending', 'approved', 'denied', 'all'] as $f) {
    $url = new moodle_url($PAGE->url, ['filter' => $f]);
    $tabs[] = new tabobject($f, $url, get_string('filter_' . $f, 'local_approve_accounts'));
}
print_tabs([$tabs], $filter);

// Get filtered records.
$status = $filtermap[$filter] ?? null;
$records = manager::get_pending($status);

if (empty($records)) {
    echo $OUTPUT->notification(get_string('nopending', 'local_approve_accounts'), 'info');
} else {
    $table = new html_table();
    $table->head = [
        get_string('fullname', 'local_approve_accounts'),
        get_string('username', 'local_approve_accounts'),
        get_string('email', 'local_approve_accounts'),
        get_string('dateregistered', 'local_approve_accounts'),
        get_string('status', 'local_approve_accounts'),
        get_string('actions', 'local_approve_accounts'),
    ];

    // Add extra columns for processed records.
    if ($filter !== 'pending') {
        $table->head[] = get_string('approvedby', 'local_approve_accounts');
        $table->head[] = get_string('timeprocessed', 'local_approve_accounts');
    }

    $table->attributes['class'] = 'generaltable';

    foreach ($records as $record) {
        // Build user fullname from the joined user fields.
        $userobj = new stdClass();
        $userobj->firstname = $record->firstname;
        $userobj->lastname = $record->lastname;
        $userobj->firstnamephonetic = $record->firstnamephonetic ?? '';
        $userobj->lastnamephonetic = $record->lastnamephonetic ?? '';
        $userobj->middlename = $record->middlename ?? '';
        $userobj->alternatename = $record->alternatename ?? '';

        $fullname = fullname($userobj);

        // Status badge.
        switch ((int) $record->status) {
            case manager::STATUS_PENDING:
                $statushtml = html_writer::span(
                    get_string('statuspending', 'local_approve_accounts'),
                    'badge badge-warning'
                );
                break;
            case manager::STATUS_APPROVED:
                $statushtml = html_writer::span(
                    get_string('statusapproved', 'local_approve_accounts'),
                    'badge badge-success'
                );
                break;
            case manager::STATUS_DENIED:
                $statushtml = html_writer::span(
                    get_string('statusdenied', 'local_approve_accounts'),
                    'badge badge-danger'
                );
                break;
            default:
                $statushtml = '-';
        }

        // Action buttons (only for pending records).
        $actions = '';
        if ((int) $record->status === manager::STATUS_PENDING) {
            $approveurl = new moodle_url('/local/approve_accounts/approve.php', [
                'id' => $record->id,
                'sesskey' => sesskey(),
            ]);
            $denyurl = new moodle_url('/local/approve_accounts/deny.php', [
                'id' => $record->id,
            ]);

            $approveform = html_writer::start_tag('form', [
                'method' => 'post',
                'action' => (new moodle_url('/local/approve_accounts/approve.php'))->out(false),
                'style' => 'display:inline',
            ]);
            $approveform .= html_writer::empty_tag('input', [
                'type' => 'hidden', 'name' => 'id', 'value' => $record->id,
            ]);
            $approveform .= html_writer::empty_tag('input', [
                'type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey(),
            ]);
            $approveform .= html_writer::tag('button',
                get_string('approve', 'local_approve_accounts'),
                ['type' => 'submit', 'class' => 'btn btn-sm btn-success mr-1']
            );
            $approveform .= html_writer::end_tag('form');

            $denylink = html_writer::link(
                $denyurl,
                get_string('deny', 'local_approve_accounts'),
                ['class' => 'btn btn-sm btn-danger']
            );

            $actions = $approveform . $denylink;
        }

        $row = [
            $fullname,
            s($record->username),
            s($record->email),
            userdate($record->timecreated),
            $statushtml,
            $actions,
        ];

        // Extra columns for non-pending views.
        if ($filter !== 'pending') {
            $approverby = '';
            if (!empty($record->approver_firstname)) {
                $approverobj = new stdClass();
                $approverobj->firstname = $record->approver_firstname;
                $approverobj->lastname = $record->approver_lastname;
                $approverby = fullname($approverobj);
            }
            $row[] = $approverby;
            $row[] = ($record->timemodified != $record->timecreated) ? userdate($record->timemodified) : '-';
        }

        $table->data[] = $row;
    }

    echo html_writer::table($table);
}

echo $OUTPUT->footer();
