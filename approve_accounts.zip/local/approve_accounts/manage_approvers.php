<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Manage designated approvers.
 *
 * @package    local_approve_accounts
 * @copyright  2025 Your Organisation
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

use local_approve_accounts\manager;

require_login();
$context = context_system::instance();
require_capability('local/approve_accounts:manageapprovers', $context);

$PAGE->set_url(new moodle_url('/local/approve_accounts/manage_approvers.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('manageapprovers', 'local_approve_accounts'));
$PAGE->set_heading(get_string('manageapprovers', 'local_approve_accounts'));
$PAGE->set_pagelayout('admin');

// Handle actions.
$action = optional_param('action', '', PARAM_ALPHA);
$userid = optional_param('userid', 0, PARAM_INT);

if ($action === 'add' && confirm_sesskey()) {
    if ($userid > 0) {
        $user = $DB->get_record('user', ['id' => $userid, 'deleted' => 0], '*', MUST_EXIST);
        if (manager::add_approver($userid)) {
            \core\notification::success(get_string('approveradded', 'local_approve_accounts', fullname($user)));
        } else {
            \core\notification::warning(get_string('approveralreadyexists', 'local_approve_accounts', fullname($user)));
        }
    }
    redirect($PAGE->url);
}

if ($action === 'remove' && confirm_sesskey()) {
    if ($userid > 0) {
        $user = $DB->get_record('user', ['id' => $userid]);
        manager::remove_approver($userid);
        if ($user) {
            \core\notification::success(get_string('approverremoved', 'local_approve_accounts', fullname($user)));
        }
    }
    redirect($PAGE->url);
}

// Build the page.
echo $OUTPUT->header();

// Current approvers table.
echo $OUTPUT->heading(get_string('currentapprovers', 'local_approve_accounts'), 3);

$approvers = manager::get_approvers();

if (empty($approvers)) {
    echo $OUTPUT->notification(get_string('noapprovers', 'local_approve_accounts'), 'info');
} else {
    $table = new html_table();
    $table->head = [
        get_string('fullname', 'local_approve_accounts'),
        get_string('email', 'local_approve_accounts'),
        get_string('dateadded', 'local_approve_accounts'),
        get_string('actions', 'local_approve_accounts'),
    ];
    $table->attributes['class'] = 'generaltable';

    foreach ($approvers as $approver) {
        // Look up the timecreated from the approvers table.
        $approverrec = $DB->get_record('local_approve_accounts_approvers', ['userid' => $approver->id]);
        $dateadded = $approverrec ? userdate($approverrec->timecreated) : '-';

        $removeurl = new moodle_url($PAGE->url, [
            'action' => 'remove',
            'userid' => $approver->id,
            'sesskey' => sesskey(),
        ]);
        $removelink = html_writer::link(
            $removeurl,
            get_string('removeapprover', 'local_approve_accounts'),
            ['class' => 'btn btn-sm btn-outline-danger']
        );

        $table->data[] = [
            fullname($approver),
            $approver->email,
            $dateadded,
            $removelink,
        ];
    }

    echo html_writer::table($table);
}

// Add approver form using Moodle's user selector.
echo $OUTPUT->heading(get_string('addapprover', 'local_approve_accounts'), 3);

$actionurl = new moodle_url($PAGE->url, ['action' => 'add', 'sesskey' => sesskey()]);

echo html_writer::start_tag('form', [
    'method' => 'get',
    'action' => $PAGE->url->out_omit_querystring(),
    'class' => 'form-inline mb-3',
]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'add']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);

// User autocomplete selector.
// We use a simple text-based search + select for compatibility.
$searchterm = optional_param('search', '', PARAM_TEXT);
echo html_writer::start_div('form-group mr-2');
echo html_writer::empty_tag('input', [
    'type' => 'text',
    'name' => 'search',
    'value' => $searchterm,
    'placeholder' => get_string('selectuser', 'local_approve_accounts'),
    'class' => 'form-control',
]);
echo html_writer::end_div();

// If a search was submitted, show matching users.
if (!empty($searchterm) && $action !== 'add') {
    $searchterm = $DB->sql_like_escape($searchterm);
    $like1 = $DB->sql_like('firstname', ':fn');
    $like2 = $DB->sql_like('lastname', ':ln');
    $like3 = $DB->sql_like('email', ':em');
    $like4 = $DB->sql_like('username', ':un');

    $sql = "SELECT id, username, firstname, lastname, email
              FROM {user}
             WHERE deleted = 0 AND suspended = 0
                   AND ({$like1} OR {$like2} OR {$like3} OR {$like4})
                   AND id NOT IN (SELECT userid FROM {local_approve_accounts_approvers})
          ORDER BY lastname, firstname
             LIMIT 20";

    $params = [
        'fn' => '%' . $searchterm . '%',
        'ln' => '%' . $searchterm . '%',
        'em' => '%' . $searchterm . '%',
        'un' => '%' . $searchterm . '%',
    ];

    $matchedusers = $DB->get_records_sql($sql, $params);

    if (!empty($matchedusers)) {
        echo html_writer::start_div('form-group mr-2');
        $options = ['' => get_string('selectuser', 'local_approve_accounts')];
        foreach ($matchedusers as $u) {
            $options[$u->id] = fullname($u) . ' (' . $u->email . ')';
        }
        echo html_writer::select($options, 'userid', '', null, ['class' => 'form-control']);
        echo html_writer::end_div();

        echo html_writer::tag('button', get_string('addapprover', 'local_approve_accounts'), [
            'type' => 'submit',
            'class' => 'btn btn-primary',
        ]);
    } else {
        echo html_writer::tag('p', get_string('noresults'), ['class' => 'text-muted ml-2']);
    }
} else {
    echo html_writer::tag('button', get_string('search'), [
        'type' => 'submit',
        'class' => 'btn btn-secondary',
        'name' => 'searchbtn',
    ]);
}

echo html_writer::end_tag('form');

echo $OUTPUT->footer();
