<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Admin settings for local_approve_accounts.
 *
 * @package    local_approve_accounts
 * @copyright  2025 Your Organisation
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_approve_accounts',
        get_string('pluginname', 'local_approve_accounts'));
    $ADMIN->add('localplugins', $settings);

    if ($ADMIN->fulltree) {
        // Enable/disable.
        $settings->add(new admin_setting_configcheckbox(
            'local_approve_accounts/enabled',
            get_string('enabled', 'local_approve_accounts'),
            get_string('enabled_desc', 'local_approve_accounts'),
            1
        ));

        // Role to assign on approval.
        $roles = role_fix_names(get_all_roles(), \context_system::instance(), ROLENAME_ORIGINAL);
        $roleoptions = [];
        foreach ($roles as $role) {
            $roleoptions[$role->id] = $role->localname;
        }
        $defaultrole = $DB->get_record('role', ['shortname' => 'student']);
        $settings->add(new admin_setting_configselect(
            'local_approve_accounts/defaultrole',
            get_string('defaultrole', 'local_approve_accounts'),
            get_string('defaultrole_desc', 'local_approve_accounts'),
            $defaultrole ? $defaultrole->id : '',
            $roleoptions
        ));

        // Auth methods to intercept.
        $authplugins = get_enabled_auth_plugins();
        $authoptions = [];
        foreach ($authplugins as $auth) {
            $authoptions[$auth] = get_string('pluginname', "auth_{$auth}");
        }
        $settings->add(new admin_setting_configmultiselect(
            'local_approve_accounts/authmethod',
            get_string('authmethod', 'local_approve_accounts'),
            get_string('authmethod_desc', 'local_approve_accounts'),
            ['email'],
            $authoptions
        ));

        // Approver notification subject.
        $settings->add(new admin_setting_configtext(
            'local_approve_accounts/notifysubject',
            get_string('notifysubject', 'local_approve_accounts'),
            get_string('notifysubject_desc', 'local_approve_accounts'),
            '',
            PARAM_TEXT
        ));

        // Approval email subject.
        $settings->add(new admin_setting_configtext(
            'local_approve_accounts/approvedsubject',
            get_string('approvedsubject', 'local_approve_accounts'),
            get_string('approvedsubject_desc', 'local_approve_accounts'),
            '',
            PARAM_TEXT
        ));

        // Denial email subject.
        $settings->add(new admin_setting_configtext(
            'local_approve_accounts/deniedsubject',
            get_string('deniedsubject', 'local_approve_accounts'),
            get_string('deniedsubject_desc', 'local_approve_accounts'),
            '',
            PARAM_TEXT
        ));

        // Link to manage approvers page.
        $manageurl = new moodle_url('/local/approve_accounts/manage_approvers.php');
        $settings->add(new admin_setting_description(
            'local_approve_accounts/manageapproverslink',
            get_string('manageapproverslink', 'local_approve_accounts'),
            \html_writer::link($manageurl, get_string('manageapprovers', 'local_approve_accounts'))
        ));
    }
}
