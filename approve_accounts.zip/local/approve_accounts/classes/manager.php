<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Business logic manager for local_approve_accounts.
 *
 * Handles approval, denial, role assignment, and email notifications.
 *
 * @package    local_approve_accounts
 * @copyright  2025 Your Organisation
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_approve_accounts;

defined('MOODLE_INTERNAL') || die();

/**
 * Manager class for account approval operations.
 */
class manager {

    /** @var int Status: pending approval. */
    const STATUS_PENDING = 0;

    /** @var int Status: approved. */
    const STATUS_APPROVED = 1;

    /** @var int Status: denied. */
    const STATUS_DENIED = 2;

    /**
     * Approve a pending registration.
     *
     * Unsuspends the user, assigns the configured role, updates the
     * pending record, and sends an approval email.
     *
     * @param int $pendingid The pending record ID.
     * @param int $approverid The user ID of the approver.
     * @return bool True on success.
     * @throws \moodle_exception If the record is invalid or already processed.
     */
    public static function approve(int $pendingid, int $approverid): bool {
        global $DB;

        $transaction = $DB->start_delegated_transaction();

        $pending = $DB->get_record('local_approve_accounts_pending', ['id' => $pendingid], '*', MUST_EXIST);

        if ((int) $pending->status !== self::STATUS_PENDING) {
            $transaction->allow_commit();
            throw new \moodle_exception('alreadyprocessed', 'local_approve_accounts');
        }

        $user = $DB->get_record('user', ['id' => $pending->userid]);
        if (!$user) {
            $transaction->allow_commit();
            throw new \moodle_exception('invalidpending', 'local_approve_accounts');
        }

        // Unsuspend the user.
        $DB->set_field('user', 'suspended', 0, ['id' => $user->id]);

        // Assign the configured role at system level.
        self::assign_role($user->id);

        // Update the pending record.
        $pending->status = self::STATUS_APPROVED;
        $pending->approvedby = $approverid;
        $pending->timemodified = time();
        $DB->update_record('local_approve_accounts_pending', $pending);

        $transaction->allow_commit();

        // Send approval email to the user.
        self::send_approved_email($user);

        return true;
    }

    /**
     * Deny a pending registration.
     *
     * Updates the pending record and sends a denial email. The user
     * remains suspended.
     *
     * @param int $pendingid The pending record ID.
     * @param int $approverid The user ID of the approver.
     * @param string $reason Optional denial reason.
     * @return bool True on success.
     * @throws \moodle_exception If the record is invalid or already processed.
     */
    public static function deny(int $pendingid, int $approverid, string $reason = ''): bool {
        global $DB;

        $transaction = $DB->start_delegated_transaction();

        $pending = $DB->get_record('local_approve_accounts_pending', ['id' => $pendingid], '*', MUST_EXIST);

        if ((int) $pending->status !== self::STATUS_PENDING) {
            $transaction->allow_commit();
            throw new \moodle_exception('alreadyprocessed', 'local_approve_accounts');
        }

        $user = $DB->get_record('user', ['id' => $pending->userid]);
        if (!$user) {
            $transaction->allow_commit();
            throw new \moodle_exception('invalidpending', 'local_approve_accounts');
        }

        // Update the pending record.
        $pending->status = self::STATUS_DENIED;
        $pending->approvedby = $approverid;
        $pending->denyreason = $reason;
        $pending->timemodified = time();
        $DB->update_record('local_approve_accounts_pending', $pending);

        $transaction->allow_commit();

        // Send denial email to the user.
        self::send_denied_email($user, $reason);

        return true;
    }

    /**
     * Assign the configured role to a user at system level.
     *
     * @param int $userid
     */
    private static function assign_role(int $userid): void {
        global $DB;

        $roleid = get_config('local_approve_accounts', 'defaultrole');
        if (empty($roleid)) {
            // Fall back to student role.
            $role = $DB->get_record('role', ['shortname' => 'student']);
            $roleid = $role ? $role->id : null;
        }

        if ($roleid) {
            $context = \context_system::instance();
            role_assign($roleid, $userid, $context->id);
        }
    }

    /**
     * Send approval notification email to the user.
     *
     * @param \stdClass $user The user record.
     */
    private static function send_approved_email(\stdClass $user): void {
        global $CFG;

        $site = get_site();
        $supportuser = \core_user::get_support_user();

        $a = new \stdClass();
        $a->fullname = fullname($user);
        $a->sitename = format_string($site->fullname);
        $a->loginurl = $CFG->wwwroot . '/login/index.php';
        $a->supportemail = $supportuser->email;

        $subject = get_config('local_approve_accounts', 'approvedsubject');
        if (empty($subject)) {
            $subject = get_string('approvedsubject_default', 'local_approve_accounts', $a);
        } else {
            $subject = self::replace_placeholders($subject, $a);
        }

        $body = get_string('email_approved_body', 'local_approve_accounts', $a);

        email_to_user($user, $supportuser, $subject, $body);
    }

    /**
     * Send denial notification email to the user.
     *
     * @param \stdClass $user The user record.
     * @param string $reason The denial reason.
     */
    private static function send_denied_email(\stdClass $user, string $reason): void {
        global $CFG;

        $site = get_site();
        $supportuser = \core_user::get_support_user();

        $a = new \stdClass();
        $a->fullname = fullname($user);
        $a->sitename = format_string($site->fullname);
        $a->supportemail = $supportuser->email;
        $a->reason = '';

        if (!empty($reason)) {
            $a->reason = get_string('email_denied_reason', 'local_approve_accounts', $reason);
        }

        $subject = get_config('local_approve_accounts', 'deniedsubject');
        if (empty($subject)) {
            $subject = get_string('deniedsubject_default', 'local_approve_accounts', $a);
        } else {
            $subject = self::replace_placeholders($subject, $a);
        }

        $body = get_string('email_denied_body', 'local_approve_accounts', $a);

        email_to_user($user, $supportuser, $subject, $body);
    }

    /**
     * Replace simple placeholders in a string.
     *
     * @param string $text The text with {sitename}, {fullname}, {email} placeholders.
     * @param \stdClass $a The replacement values.
     * @return string
     */
    private static function replace_placeholders(string $text, \stdClass $a): string {
        $replacements = [
            '{sitename}' => $a->sitename ?? '',
            '{fullname}' => $a->fullname ?? '',
            '{email}' => $a->email ?? '',
        ];
        return str_replace(array_keys($replacements), array_values($replacements), $text);
    }

    /**
     * Get all designated approver user records.
     *
     * @return array Array of user records.
     */
    public static function get_approvers(): array {
        global $DB;

        $sql = "SELECT u.*
                  FROM {local_approve_accounts_approvers} a
                  JOIN {user} u ON u.id = a.userid
                 WHERE u.deleted = 0 AND u.suspended = 0
              ORDER BY u.lastname, u.firstname";

        return $DB->get_records_sql($sql);
    }

    /**
     * Check if a user is a designated approver.
     *
     * @param int $userid
     * @return bool
     */
    public static function is_approver(int $userid): bool {
        global $DB;
        return $DB->record_exists('local_approve_accounts_approvers', ['userid' => $userid]);
    }

    /**
     * Add a user as a designated approver.
     *
     * @param int $userid
     * @return bool True if added, false if already exists.
     */
    public static function add_approver(int $userid): bool {
        global $DB;

        if ($DB->record_exists('local_approve_accounts_approvers', ['userid' => $userid])) {
            return false;
        }

        $record = new \stdClass();
        $record->userid = $userid;
        $record->timecreated = time();
        $DB->insert_record('local_approve_accounts_approvers', $record);

        return true;
    }

    /**
     * Remove a user from designated approvers.
     *
     * @param int $userid
     * @return bool True if removed.
     */
    public static function remove_approver(int $userid): bool {
        global $DB;
        return $DB->delete_records('local_approve_accounts_approvers', ['userid' => $userid]);
    }

    /**
     * Get pending registrations, optionally filtered by status.
     *
     * @param int|null $status Filter by status, or null for all.
     * @return array Array of pending records with joined user data.
     */
    public static function get_pending(?int $status = null): array {
        global $DB;

        $params = [];
        $where = '1 = 1';

        if ($status !== null) {
            $where = 'p.status = :status';
            $params['status'] = $status;
        }

        $sql = "SELECT p.*, u.username, u.firstname, u.lastname, u.email,
                       u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename,
                       a.firstname AS approver_firstname, a.lastname AS approver_lastname
                  FROM {local_approve_accounts_pending} p
                  JOIN {user} u ON u.id = p.userid
             LEFT JOIN {user} a ON a.id = p.approvedby
                 WHERE {$where}
              ORDER BY p.timecreated DESC";

        return $DB->get_records_sql($sql, $params);
    }
}
