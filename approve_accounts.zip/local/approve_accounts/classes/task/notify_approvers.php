<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Adhoc task to notify designated approvers about a new registration.
 *
 * @package    local_approve_accounts
 * @copyright  2025 Your Organisation
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_approve_accounts\task;

defined('MOODLE_INTERNAL') || die();

use local_approve_accounts\manager;

/**
 * Sends email notifications to all designated approvers when a new user registers.
 */
class notify_approvers extends \core\task\adhoc_task {

    /**
     * Execute the task.
     */
    public function execute() {
        global $CFG, $DB;

        $data = $this->get_custom_data();
        if (empty($data->userid)) {
            return;
        }

        $user = $DB->get_record('user', ['id' => $data->userid]);
        if (!$user) {
            return;
        }

        $approvers = manager::get_approvers();
        if (empty($approvers)) {
            mtrace('  No designated approvers found. Skipping notification.');
            return;
        }

        $site = get_site();
        $supportuser = \core_user::get_support_user();

        $a = new \stdClass();
        $a->fullname = fullname($user);
        $a->email = $user->email;
        $a->username = $user->username;
        $a->date = userdate($user->timecreated);
        $a->pendingurl = $CFG->wwwroot . '/local/approve_accounts/pending.php';

        // Build subject.
        $subject = get_config('local_approve_accounts', 'notifysubject');
        if (empty($subject)) {
            $subject = get_string('notifysubject_default', 'local_approve_accounts', $a);
        } else {
            $subject = str_replace(
                ['{fullname}', '{email}'],
                [$a->fullname, $a->email],
                $subject
            );
        }

        // Build body.
        $body = get_string('email_approver_body', 'local_approve_accounts', $a);

        // Send to each approver.
        foreach ($approvers as $approver) {
            $result = email_to_user($approver, $supportuser, $subject, $body);
            if ($result) {
                mtrace("  Notified approver: {$approver->email}");
            } else {
                mtrace("  Failed to notify approver: {$approver->email}");
            }
        }
    }
}
