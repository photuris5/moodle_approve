<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Event observer for local_approve_accounts.
 *
 * Listens for user_created events and suspends self-registered users
 * pending approval by designated approvers.
 *
 * @package    local_approve_accounts
 * @copyright  2025 Your Organisation
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_approve_accounts;

defined('MOODLE_INTERNAL') || die();

/**
 * Observer class for handling user creation events.
 */
class observer {

    /**
     * Handle the user_created event.
     *
     * Checks if the new user was created via a monitored auth method,
     * suspends them, creates a pending record, and queues notification.
     *
     * @param \core\event\user_created $event
     */
    public static function user_created(\core\event\user_created $event) {
        global $DB, $USER;

        // Check if plugin is enabled.
        if (!get_config('local_approve_accounts', 'enabled')) {
            return;
        }

        // Skip if an admin is creating the user (manual account creation).
        if (isloggedin() && !isguestuser() && is_siteadmin()) {
            return;
        }

        $userid = $event->objectid;
        $user = $DB->get_record('user', ['id' => $userid]);
        if (!$user) {
            return;
        }

        // Check if this auth method should be intercepted.
        $authmethods = get_config('local_approve_accounts', 'authmethod');
        if (empty($authmethods)) {
            $authmethods = 'email';
        }
        $allowedauths = array_map('trim', explode(',', $authmethods));
        if (!in_array($user->auth, $allowedauths)) {
            return;
        }

        // Suspend the user immediately.
        $DB->set_field('user', 'suspended', 1, ['id' => $userid]);
        \core\session\manager::kill_user_sessions($userid);

        // Create a pending approval record.
        $pending = new \stdClass();
        $pending->userid = $userid;
        $pending->status = manager::STATUS_PENDING;
        $pending->timecreated = time();
        $pending->timemodified = time();
        $DB->insert_record('local_approve_accounts_pending', $pending);

        // Queue adhoc task to notify approvers.
        $task = new \local_approve_accounts\task\notify_approvers();
        $task->set_custom_data((object) ['userid' => $userid]);
        \core\task\manager::queue_adhoc_task($task, true);
    }
}
